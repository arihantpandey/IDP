//pins of the arduino

#define SERVOCURRENT A0
#define IRDISTANCE A1
#define USTRIG A2
#define USECHO A3
#define REAR 0
#define LEFT 1
#define MIDDLE 2
#define RIGHT 3
#define SENSOR_REAR 0
#define SENSOR_LEFT 1
#define SENSOR_MIDDLE 2
#define SENSOR_RIGHT 3
#define BUTTON 4
#define AMBERLED 5
#define GREENLED 6
#define REDLED 7
#define BLUELED1 8
#define BLUELED2 9
#define SERVOCONTROL 10
#define BLUELED3 11
#define BLUELED4 12

#define LEFTMOTOR 1
#define RIGHTMOTOR 4
